#!/usr/bin/env python3
"""Regenerate descriptive tables and figures from the frozen stress experiment."""
import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import numpy as np
import pandas as pd

from budget_scaling import select_factor


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', type=Path, default=Path('results-revision/research-audit/budget-final'))
    ap.add_argument('--figures', type=Path, default=Path('paper/figs/research'))
    ap.add_argument('--tables', type=Path, default=Path('paper/tables'))
    args = ap.parse_args()
    args.figures.mkdir(parents=True, exist_ok=True)
    args.tables.mkdir(parents=True, exist_ok=True)
    d = pd.read_csv(args.root/'runs.csv')
    d['abstained'] = d.status.eq('ABSTAIN')
    d['submitted'] = ~d.abstained
    d['failed_output'] = (~d.rounded_optimal) & d.submitted
    summary = d.groupby(['solver','method'],sort=False).agg(n=('status','size'),
                 attempted=('submitted','sum'), abstained=('abstained','sum'),
                 exact_optimal=('rounded_optimal','sum'), failed=('failed_output','sum'))
    summary.to_csv(args.root/'summary.csv')
    methods = ['Base','GM','L2','GM-tight','Dyadic-GM','Budget-only','Budget-GM','Budget-dyadic','Budget-round']
    lines = [r'\begin{tabular}{lrrrrrr}', r'\toprule',
             r'& \multicolumn{3}{c}{HiGHS 1.15.1} & \multicolumn{3}{c}{Gurobi 13.0.2} \\',
             r'Method & Verified & Other & Abstain & Verified & Other & Abstain \\', r'\midrule']
    for method in methods:
        vals = []
        for solver in ['highs','gurobi']:
            r = summary.loc[(solver,method)]
            vals += [str(int(r.exact_optimal)), str(int(r.failed)), str(int(r.abstained))]
        lines.append(method+' & '+' & '.join(vals)+r' \\')
    lines += [r'\bottomrule',r'\end{tabular}']
    (args.tables/'budget-results.tex').write_text('\n'.join(lines)+'\n')
    plt.rcParams.update({'font.size':11, 'pdf.fonttype':42, 'ps.fonttype':42})
    fig, axes = plt.subplots(1,2,figsize=(9,5.2),sharey=True,layout='constrained')
    for ax, solver in zip(axes,['highs','gurobi']):
        a = d[d.solver.eq(solver)]
        grid = np.empty((len(methods),4))
        for i, method in enumerate(methods):
            for j, e in enumerate([0,3,6,9]):
                s = a[a.method.eq(method)&a.exponent.eq(e)]
                grid[i,j] = 100*s.rounded_optimal.mean()
        ax.imshow(grid,cmap='Blues',vmin=0,vmax=100,aspect='auto')
        for i,method in enumerate(methods):
            for j,e in enumerate([0,3,6,9]):
                s = a[a.method.eq(method)&a.exponent.eq(e)]
                if s.abstained.all():
                    ax.add_patch(Rectangle((j-.5,i-.5),1,1,facecolor='#eeeeee',edgecolor='#aaaaaa',hatch='//'))
                    label, color = 'abstain', 'black'
                else:
                    label = f'{int(s.rounded_optimal.sum())}/{len(s)}'
                    color = 'white' if grid[i,j]>65 else 'black'
                ax.text(j,i,label,ha='center',va='center',fontsize=11,color=color)
        ax.set_xticks(range(4),[r'$10^0$',r'$10^3$',r'$10^6$',r'$10^9$'])
        ax.set_yticks(range(len(methods)),methods)
        ax.set_xlabel('Coefficient multiplier')
        ax.set_title('(a) HiGHS 1.15.1' if solver=='highs' else '(b) Gurobi 13.0.2')
    fig.savefig(args.figures/'budget-verification.pdf',bbox_inches='tight')
    fig.savefig(args.figures/'budget-verification.png',dpi=180,bbox_inches='tight')
    plt.close(fig)

    # Phase diagram of contract compatibility, with exact analytic boundaries.
    logs_M = np.linspace(-3,12,151)
    logs_delta = np.linspace(-14,2,161)
    regimes = np.zeros((len(logs_delta),len(logs_M)))
    for i,ld in enumerate(logs_delta):
        for j,lM in enumerate(logs_M):
            row = [10.**(lM-4),10.**lM]
            decision = select_factor(row,10.**ld,coefficient_floor=1e-6,coefficient_ceiling=1e6)
            regimes[i,j] = 0 if decision.factor is None else (1 if decision.reason=='projected' else 2)
    from matplotlib.colors import ListedColormap
    fig,ax = plt.subplots(figsize=(6.5,4.2),layout='constrained')
    ax.imshow(regimes,origin='lower',extent=[-3,12,-14,2],aspect='auto',interpolation='nearest',
              cmap=ListedColormap(['#bdbdbd','#e9c46a','#2a9d8f']),vmin=0,vmax=2)
    ax.plot(logs_M,logs_M-12,'k-',lw=1.2,label=r'Feasibility: $\delta=\epsilon M/U$')
    ax.plot(logs_M,logs_M-8,'k--',lw=1.2,label=r'Unconstrained GM becomes admissible')
    ax.set(xlabel=r'$\log_{10} M$',ylabel=r'$\log_{10}\delta$',ylim=(-14,2))
    ax.text(4,-10.5,'Incompatible specifications',ha='center',fontsize=9)
    ax.text(6.5,-3.5,'Projected factor',ha='center',fontsize=9)
    ax.text(1,0,'Unconstrained GM',ha='center',fontsize=9)
    ax.legend(loc='lower right',fontsize=8,framealpha=.9)
    ax.set_title(r'$M/m=10^4$, $[\ell,U]=[10^{-6},10^6]$, $\epsilon=10^{-6}$')
    fig.savefig(args.figures/'budget-compatibility.pdf',bbox_inches='tight')
    fig.savefig(args.figures/'budget-compatibility.png',dpi=180,bbox_inches='tight')
    plt.close(fig)
    print(summary.to_string())


if __name__=='__main__':
    main()
